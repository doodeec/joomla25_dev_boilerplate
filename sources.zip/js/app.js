/**
 * Joomla 2.5.X custom template boilerplate | 2014
 */

(function($){
    $(document).ready(function(){
        var body = $('.body');        
        body.addClass('js-ready');
    });
})(jQuery);